import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';

// 1 = Wall, 2 = Coin, 9 = Start
const layout = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 9, 0, 0, 1, 2, 0, 2, 1],
    [1, 0, 1, 0, 1, 0, 1, 0, 1],
    [1, 2, 1, 0, 0, 0, 1, 0, 1],
    [1, 0, 1, 1, 1, 0, 1, 2, 1],
    [1, 0, 0, 2, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1]
];

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x222222);
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Lighting
const light = new THREE.AmbientLight(0xffffff, 0.9);
scene.add(light);

// Textures
const loader = new THREE.TextureLoader();
const wallTex = loader.load('https://threejs.org/examples/textures/brick_diffuse.jpg');
const floorTex = loader.load('https://threejs.org/examples/textures/floors/FloorsCheckerboard_S_Diffuse.jpg');

const wallMat = new THREE.MeshStandardMaterial({ map: wallTex });
const floorMat = new THREE.MeshStandardMaterial({ map: floorTex });

// Objects
let walls = [];
let coins = [];

layout.forEach((row, z) => {
    row.forEach((type, x) => {
        const px = x * 2.5;
        const pz = z * 2.5;
        if (type === 1) {
            const wall = new THREE.Mesh(new THREE.BoxGeometry(2.5, 4, 2.5), wallMat);
            wall.position.set(px, 2, pz);
            scene.add(wall);
            walls.push(wall);
        } else if (type === 2) {
            const coin = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.1, 10, 20), new THREE.MeshStandardMaterial({color: 0xffcc00}));
            coin.position.set(px, 1, pz);
            scene.add(coin);
            coins.push(coin);
        } else if (type === 9) {
            camera.position.set(px, 1.6, pz);
        }
    });
});

const ground = new THREE.Mesh(new THREE.PlaneGeometry(100, 100), floorMat);
ground.rotation.x = -Math.PI/2;
scene.add(ground);

// Controls
const controls = new PointerLockControls(camera, document.body);
const menu = document.getElementById('ui-menu');
const win = document.getElementById('victory');
const coinUI = document.getElementById('coins-left');

document.addEventListener('click', () => controls.lock());
controls.addEventListener('lock', () => menu.style.display = 'none');
controls.addEventListener('unlock', () => { if(coins.length > 0) menu.style.display = 'flex'; });

let move = { f: false, b: false, l: false, r: false };
let vel = new THREE.Vector3();
let jumping = false;

document.addEventListener('keydown', (e) => {
    if(e.code === 'KeyW') move.f = true;
    if(e.code === 'KeyS') move.b = true;
    if(e.code === 'KeyA') move.l = true;
    if(e.code === 'KeyD') move.r = true;
    if(e.code === 'Space' && !jumping) { vel.y = 10; jumping = true; }
});
document.addEventListener('keyup', (e) => {
    if(e.code === 'KeyW') move.f = false;
    if(e.code === 'KeyS') move.b = false;
    if(e.code === 'KeyA') move.l = false;
    if(e.code === 'KeyD') move.r = false;
});

coinUI.innerText = `Coins: ${coins.length}`;

function loop() {
    requestAnimationFrame(loop);
    const dt = 0.016; // Roughly 60fps

    if (controls.isLocked) {
        vel.x -= vel.x * 10 * dt;
        vel.z -= vel.z * 10 * dt;
        vel.y -= 25 * dt; // Gravity

        let zDir = Number(move.f) - Number(move.b);
        let xDir = Number(move.r) - Number(move.l);

        if (move.f || move.b) vel.z -= zDir * 40 * dt;
        if (move.l || move.r) vel.x -= xDir * 40 * dt;

        controls.moveRight(-vel.x * dt);
        controls.moveForward(-vel.z * dt);
        camera.position.y += vel.y * dt;

        if (camera.position.y < 1.6) {
            vel.y = 0; camera.position.y = 1.6; jumping = false;
        }

        // Wall Collision
        let pPos = camera.position;
        walls.forEach(w => {
            if (pPos.distanceTo(w.position) < 1.5) {
                controls.moveForward(vel.z * dt);
                controls.moveRight(vel.x * dt);
            }
        });

        // Coins
        for (let i = coins.length - 1; i >= 0; i--) {
            coins[i].rotation.y += 0.05;
            if (camera.position.distanceTo(coins[i].position) < 1) {
                scene.remove(coins[i]);
                coins.splice(i, 1);
                coinUI.innerText = `Coins: ${coins.length}`;
                if (coins.length === 0) {
                    controls.unlock();
                    win.style.display = 'flex';
                }
            }
        }
    }
    renderer.render(scene, camera);
}
loop();